using Xunit;
using Moq;
using FSTweather.Logic;
using FSTweather.Services.Interfaces;
using FSTweather.Models;
using FSTweather.Configuration;
using System.Net;

namespace FSTweather.Tests;

public class ErrorHandlingTests
{
    private readonly Mock<ISmhiApiClient> _mockApiClient;
    private readonly TemperatureService _temperatureService;
    private readonly RainfallService _rainfallService;

    public ErrorHandlingTests()
    {
        _mockApiClient = new Mock<ISmhiApiClient>();
        _temperatureService = new TemperatureService(_mockApiClient.Object);
        
        var settings = new RainfallServiceSettings { LundStationId = 1 };
        _rainfallService = new RainfallService(_mockApiClient.Object, settings);
    }

    [Fact]
    public async Task TemperatureService_WhenApiThrowsHttpException_HandlesGracefully()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 1, "latest-hour"))
            .ThrowsAsync(new HttpRequestException("Network error"));

        // Act
        var result = await _temperatureService.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Null(result); // Should return null when no data is available
    }

    [Fact]
    public async Task TemperatureService_WhenApiReturnsNull_HandlesGracefully()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 1, "latest-hour"))
            .ReturnsAsync((StationData?)null);

        // Act
        var result = await _temperatureService.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task RainfallService_WhenApiThrowsException_HandlesGracefully()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Lund", Active = true }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(5))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(5, 1, "latest-months"))
            .ThrowsAsync(new HttpRequestException("API unavailable"));

        // Act
        var result = await _rainfallService.GetTotalRainfallInLundAsync();

        // Assert
        Assert.Null(result.Rainfall);
    }

    [Fact]
    public async Task TemperatureService_WithCancellationToken_RespectsCancellation()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true },
                new() { Id = 2, Name = "Station 2", Active = true }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        var cts = new CancellationTokenSource();
        cts.Cancel(); // Cancel immediately

        // Act
        var result = await _temperatureService.GetAverageTemperatureAsync(cts.Token);

        // Assert
        Assert.Null(result); // Should return null when cancelled before processing any data
    }

    [Fact]
    public async Task TemperatureService_WhenStationDataHasNoValues_SkipsStation()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true },
                new() { Id = 2, Name = "Station 2", Active = true }
            }
        };

        var stationData1 = new StationData
        {
            Values = new List<ValueEntry>() // Empty values list
        };

        var stationData2 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "15.0" }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 1, "latest-hour"))
            .ReturnsAsync(stationData1);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 2, "latest-hour"))
            .ReturnsAsync(stationData2);

        // Act
        var result = await _temperatureService.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Equal(15.0, result); // Should only include station 2
    }
}