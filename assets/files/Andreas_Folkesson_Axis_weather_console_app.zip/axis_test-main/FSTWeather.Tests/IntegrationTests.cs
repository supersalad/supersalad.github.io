using Xunit;
using System.Text.Json;
using FSTweather.Models;
using FSTweather.Services;
using FSTweather.Services.Interfaces;
using FSTweather.Logic;
using FSTweather.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FSTweather.Tests;

public class IntegrationTests
{
    private readonly string _testDataPath;

    public IntegrationTests()
    {
        _testDataPath = Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "testdata");
    }

    [Fact]
    public async Task RainfallService_WithRealTestData_CalculatesCorrectTotal()
    {
        // Arrange
        var settings = new RainfallServiceSettings { LundStationId = 53430 };
        var testApiClient = new TestDataSmhiApiClient(_testDataPath);
        var rainfallService = new RainfallService(testApiClient, settings);

        // Act
        var result = await rainfallService.GetTotalRainfallInLundAsync();

        // Assert
        Assert.NotNull(result.Rainfall);
        Assert.True(result.Rainfall > 0, "Total rainfall should be greater than 0");
        Assert.True(result.From > 0, "From timestamp should be set");
        Assert.True(result.To > 0, "To timestamp should be set");
        Assert.True(result.To > result.From, "To timestamp should be after From timestamp");
    }

    [Fact]
    public async Task TemperatureService_WithRealTestData_ReturnsValidAverage()
    {
        // Arrange
        var testApiClient = new TestDataSmhiApiClient(_testDataPath);
        var temperatureService = new TemperatureService(testApiClient);

        // Act
        var result = await temperatureService.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert - Since we're using test data, we expect a valid temperature
        Assert.NotNull(result);
        Assert.True(result >= -50 && result <= 50, "Temperature should be within a reasonable range");
    }

    // Test implementation of SmhiApiClient that reads from test data files
    private class TestDataSmhiApiClient : ISmhiApiClient
    {
        private readonly string _testDataPath;

        public TestDataSmhiApiClient(string testDataPath)
        {
            _testDataPath = testDataPath;
        }

        public async Task<StationList> GetStationsAsync(int parameterId)
        {
            // For rainfall (parameter 5), return a simple station list with Lund
            if (parameterId == 5)
            {
                return new StationList
                {
                    Stations = new List<Station>
                    {
                        new() { Id = 53430, Name = "Lund", Active = true }
                    }
                };
            }
            
            // For temperature (parameter 1), return a simple station list
            return new StationList
            {
                Stations = new List<Station>
                {
                    new() { Id = 53430, Name = "Lund", Active = true }
                }
            };
        }

        public async Task<StationData?> GetStationDataAsync(int parameterId, int stationId, string period)
        {
            // Load appropriate test data based on parameter
            string fileName = parameterId == 5 ? "LundStationRain.json" : "LundStationTemp.json";
            string filePath = Path.Combine(_testDataPath, fileName);
            
            if (!File.Exists(filePath))
            {
                return null;
            }

            var json = await File.ReadAllTextAsync(filePath);
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<StationData>(json, options);
        }
    }
}