using Xunit;
using Moq;
using FSTweather.Logic;
using FSTweather.Services.Interfaces;
using FSTweather.Models;
using FSTweather.Configuration;

namespace FSTweather.Tests;

public class RainfallServiceTests
{
    private readonly Mock<ISmhiApiClient> _mockApiClient;
    private readonly RainfallService _service;
    private readonly RainfallServiceSettings _settings;

    public RainfallServiceTests()
    {
        _mockApiClient = new Mock<ISmhiApiClient>();
        _settings = new RainfallServiceSettings { LundStationId = 1 };
        _service = new RainfallService(_mockApiClient.Object, _settings);
    }

    [Fact]
    public async Task GetTotalRainfallInLundAsync_WithValidData_SumsCorrectly()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Lund", Active = true }
            }
        };

        var stationData = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "10.5" },
                new() { ValueString = "20.3" },
                new() { ValueString = "15.2" }
            },
            Period = new PeriodData 
            { 
                From = 1234567890000,
                To = 1234567990000 
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(5))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(5, 1, "latest-months"))
            .ReturnsAsync(stationData);

        // Act
        var result = await _service.GetTotalRainfallInLundAsync();

        // Assert
        Assert.Equal(46.0, result.Rainfall);  // 10.5 + 20.3 + 15.2
        Assert.Equal(1234567890000, result.From);
        Assert.Equal(1234567990000, result.To);
    }

    [Fact]
    public async Task GetTotalRainfallInLundAsync_WithMissingData_ReturnsNull()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Lund", Active = true }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(5))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(5, 1, "latest-months"))
            .ReturnsAsync((StationData?)null);

        // Act
        var result = await _service.GetTotalRainfallInLundAsync();

        // Assert
        Assert.Null(result.Rainfall);
    }

    [Fact]
    public async Task GetTotalRainfallInLundAsync_WithEmptyValues_ReturnsZero()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Lund", Active = true }
            }
        };

        var stationData = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "" },
                new() { ValueString = "" }
            },
            Period = new PeriodData 
            { 
                From = 1234567890000,
                To = 1234567990000 
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(5))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(5, 1, "latest-months"))
            .ReturnsAsync(stationData);

        // Act
        var result = await _service.GetTotalRainfallInLundAsync();

        // Assert
        Assert.Equal(0.0, result.Rainfall);
        Assert.Equal(1234567890000, result.From);
        Assert.Equal(1234567990000, result.To);
    }

    [Fact]
    public async Task GetTotalRainfallInLundAsync_WithMixedValues_SumsOnlyValidValues()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Lund", Active = true }
            }
        };

        var stationData = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "10.5" },
                new() { ValueString = "" },  // Should be treated as 0
                new() { ValueString = "15.2" },
                new() { ValueString = "5.0" }
            },
            Period = new PeriodData 
            { 
                From = 1234567890000,
                To = 1234567990000 
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(5))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(5, 1, "latest-months"))
            .ReturnsAsync(stationData);

        // Act
        var result = await _service.GetTotalRainfallInLundAsync();

        // Assert
        Assert.Equal(30.7, result.Rainfall);  // 10.5 + 0 + 15.2 + 5.0
    }

    [Fact]
    public async Task GetTotalRainfallInLundAsync_WithNoStations_ReturnsNull()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>()  // Empty stations list
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(5))
            .ReturnsAsync(stationList);

        // Act
        var result = await _service.GetTotalRainfallInLundAsync();

        // Assert
        Assert.Null(result.Rainfall);
    }
}