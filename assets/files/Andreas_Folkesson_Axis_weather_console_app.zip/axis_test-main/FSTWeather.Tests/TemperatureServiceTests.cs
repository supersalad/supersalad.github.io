using Xunit;
using Moq;
using FSTweather.Logic;
using FSTweather.Services.Interfaces;
using FSTweather.Models;

namespace FSTweather.Tests;

public class TemperatureServiceTests
{
    private readonly Mock<ISmhiApiClient> _mockApiClient;
    private readonly TemperatureService _service;

    public TemperatureServiceTests()
    {
        _mockApiClient = new Mock<ISmhiApiClient>();
        _service = new TemperatureService(_mockApiClient.Object);
    }

    [Fact]
    public async Task GetAverageTemperatureAsync_WithValidData_CalculatesCorrectAverage()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true },
                new() { Id = 2, Name = "Station 2", Active = true }
            }
        };

        var stationData1 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "10.0" }
            }
        };

        var stationData2 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "20.0" }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 1, "latest-hour"))
            .ReturnsAsync(stationData1);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 2, "latest-hour"))
            .ReturnsAsync(stationData2);

        // Act
        var result = await _service.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Equal(15.0, result);
    }

    [Fact]
    public async Task GetAverageTemperatureAsync_WithNullValues_SkipsNullValues()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true },
                new() { Id = 2, Name = "Station 2", Active = true }
            }
        };

        var stationData1 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "10.0" }
            }
        };

        var stationData2 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "" }  // Empty string - should be excluded from average
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 1, "latest-hour"))
            .ReturnsAsync(stationData1);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 2, "latest-hour"))
            .ReturnsAsync(stationData2);

        // Act
        var result = await _service.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Equal(10.0, result);  // Only station 1 should be included, station 2 excluded due to empty data
    }

    [Fact]
    public async Task GetAverageTemperatureAsync_WithNoActiveStations_ReturnsNull()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = false },
                new() { Id = 2, Name = "Station 2", Active = false }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        // Act
        var result = await _service.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task GetAverageTemperatureAsync_WithAllEmptyData_ReturnsNull()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true },
                new() { Id = 2, Name = "Station 2", Active = true }
            }
        };

        var stationData1 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "" }
            }
        };

        var stationData2 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "" }
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 1, "latest-hour"))
            .ReturnsAsync(stationData1);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 2, "latest-hour"))
            .ReturnsAsync(stationData2);

        // Act
        var result = await _service.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task GetAverageTemperatureAsync_WithMixedData_CalculatesCorrectAverage()
    {
        // Arrange
        var stationList = new StationList 
        { 
            Stations = new List<Station>
            {
                new() { Id = 1, Name = "Station 1", Active = true },
                new() { Id = 2, Name = "Station 2", Active = true },
                new() { Id = 3, Name = "Station 3", Active = true }
            }
        };

        var stationData1 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "10.0" }
            }
        };

        var stationData2 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "20.0" }
            }
        };

        var stationData3 = new StationData
        {
            Values = new List<ValueEntry>
            {
                new() { ValueString = "" }  // Should be excluded
            }
        };

        _mockApiClient.Setup(x => x.GetStationsAsync(1))
            .ReturnsAsync(stationList);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 1, "latest-hour"))
            .ReturnsAsync(stationData1);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 2, "latest-hour"))
            .ReturnsAsync(stationData2);

        _mockApiClient.Setup(x => x.GetStationDataAsync(1, 3, "latest-hour"))
            .ReturnsAsync(stationData3);

        // Act
        var result = await _service.GetAverageTemperatureAsync(CancellationToken.None);

        // Assert
        Assert.Equal(15.0, result);  // (10.0 + 20.0) / 2 = 15.0, station 3 excluded
    }
}