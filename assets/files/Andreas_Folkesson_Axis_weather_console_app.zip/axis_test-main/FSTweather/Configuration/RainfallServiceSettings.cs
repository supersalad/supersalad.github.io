namespace FSTweather.Configuration;

public class RainfallServiceSettings
{
    public int LundStationId { get; set; }
}