namespace FSTweather.Configuration;

public class SmhiApiSettings
{
    public string BaseUrl { get; set; } = string.Empty;
}