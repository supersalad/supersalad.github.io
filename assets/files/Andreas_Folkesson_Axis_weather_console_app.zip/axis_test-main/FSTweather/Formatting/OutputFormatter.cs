using System.Globalization;

namespace FSTweather.Formatting;

public static class OutputFormatter
{
    public static string FormatTemperature(double temperature)
        => $"{temperature.ToString("F1", CultureInfo.InvariantCulture)}°C";

    public static string FormatRainfall(double rainfall)
        => $"{rainfall.ToString("F1", CultureInfo.InvariantCulture)} mm";

    public static string FormatDateRange(long fromTimestamp, long toTimestamp)
    {
        var from = DateTimeOffset.FromUnixTimeMilliseconds(fromTimestamp);
        var to = DateTimeOffset.FromUnixTimeMilliseconds(toTimestamp);
        return $"between {from:yyyy-MM-dd} and {to:yyyy-MM-dd}";
    }
}