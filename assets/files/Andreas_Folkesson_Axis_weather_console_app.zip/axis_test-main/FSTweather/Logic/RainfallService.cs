using FSTweather.Services.Interfaces;
using FSTweather.Configuration;
using FSTweather.Models;

namespace FSTweather.Logic;

public class RainfallService
{
    private readonly ISmhiApiClient _smhiApiClient;
    private readonly RainfallServiceSettings _settings;

    public RainfallService(ISmhiApiClient smhiApiClient, RainfallServiceSettings settings)
    {
        _smhiApiClient = smhiApiClient;
        _settings = settings;
    }

    public async Task<(double? Rainfall, long From, long To)> GetTotalRainfallInLundAsync()
    {
        try
        {
            // Get the latest month of data
            var data = await _smhiApiClient.GetStationDataAsync(
                (int)Parameter.Rainfall, 
                _settings.LundStationId, 
                Period.LatestMonths);

            if (data?.Values == null || !data.Values.Any())
            {
                Console.WriteLine("No rainfall data available for Lund");
                return (null, 0, 0);
            }

            // Sum up all non-null rainfall values
            var totalRainfall = data.Values
                .Sum(v => v.Value);

            return (totalRainfall, data.Period.From, data.Period.To);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error getting rainfall data: {ex.Message}");
            return (null, 0, 0);
        }
    }
}