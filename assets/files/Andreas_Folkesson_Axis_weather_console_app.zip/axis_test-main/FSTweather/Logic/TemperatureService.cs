using FSTweather.Services.Interfaces;
using FSTweather.Formatting;
using FSTweather.Models;
using System;
using System.Linq;

namespace FSTweather.Logic;

public class TemperatureService
{
    private readonly ISmhiApiClient _smhiApiClient;

    private const int SleepDurationMs = 100;

    public TemperatureService(ISmhiApiClient smhiApiClient)
    {
        _smhiApiClient = smhiApiClient;
    }

    public async Task<double?> GetAverageTemperatureAsync(CancellationToken token)
    {
        // Get all temperature stations (parameter 1 is temperature)
        var stations = await _smhiApiClient.GetStationsAsync((int)Parameter.Temperature);
        var activeStations = stations.Stations.Where(s => s.Active).ToList();

        if (!activeStations.Any())
        {
            Console.WriteLine("No active temperature stations found.");
            return null;
        }

        var temperatures = new List<double>();
        var skippedCount = 0;

        foreach (var station in activeStations)
        {
            if (token.IsCancellationRequested)
            {
                break;
            }

            try
            {
                var data = await _smhiApiClient.GetStationDataAsync((int)Parameter.Temperature, station.Id, Period.LatestHour);
                if (data?.Values.Any() == true && !string.IsNullOrEmpty(data.Values[0].ValueString))
                {
                    temperatures.Add(data.Values[0].Value);
                }
                else
                {
                    skippedCount++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to get data for station {station.Name}: {ex.Message}");
                skippedCount++;
            }
        }

        if (!temperatures.Any())
        {
            Console.WriteLine("No temperature readings available.");
            return null;
        }

        Console.WriteLine($"Processed {activeStations.Count} stations ({skippedCount} skipped)");
        return temperatures.Average();
    }

    public async Task PrintStationTemperaturesAsync(CancellationToken token)
    {

        while (token.IsCancellationRequested == false)
        {
            // Get all temperature stations
            var stations = await _smhiApiClient.GetStationsAsync(1);
            var activeStations = stations.Stations.Where(s => s.Active).ToList();

            if (!activeStations.Any())
            {
                Console.WriteLine("No active temperature stations found.");
                return;
            }

            Console.WriteLine($"Found {activeStations.Count} active temperature stations. Press Ctrl+C to cancel.");
            Console.WriteLine("\nStation Temperatures:");
            Console.WriteLine("--------------------");

            foreach (var station in activeStations)
            {
                if (token.IsCancellationRequested)
                {
                    Console.WriteLine("\nOperation cancelled.");
                    return;
                }

                try
                {
                    var data = await _smhiApiClient.GetStationDataAsync((int)Parameter.Temperature, station.Id, Period.LatestHour);
                    if (data?.Values.Any() == true)
                    {
                        var temp = data.Values[0].Value;
                        Console.WriteLine($"{station.Name}: {OutputFormatter.FormatTemperature(temp)}");
                    }
                    else
                    {
                        Console.WriteLine($"{station.Name}: No data available");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{station.Name}: Error - {ex.Message}");
                }
            }

            Console.WriteLine($"Continuous station temperatures continues in {SleepDurationMs}ms. Press any key to stop.");
            System.Threading.Thread.Sleep(SleepDurationMs);
        }
    }
}