namespace FSTweather.Models;

public enum Parameter
{
    Temperature = 1,
    Rainfall = 5
}