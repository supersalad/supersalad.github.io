using System.Runtime.Serialization;

namespace FSTweather.Models;

public static class Period
{
    public const string LatestHour = "latest-hour";

    public const string LatestMonths = "latest-months";
}