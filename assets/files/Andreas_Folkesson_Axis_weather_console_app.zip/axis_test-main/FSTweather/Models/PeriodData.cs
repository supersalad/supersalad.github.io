using System.Text.Json.Serialization;

namespace FSTweather.Models;

public class PeriodData
{
    [JsonPropertyName("from")]
    public long From { get; set; }

    [JsonPropertyName("to")]
    public long To { get; set; }

    [JsonPropertyName("summary")]
    public string Summary { get; set; } = string.Empty;

    [JsonPropertyName("sampling")]
    public string Sampling { get; set; } = string.Empty;
}