using System.Text.Json.Serialization;

namespace FSTweather.Models;

public class StationData
{
    [JsonPropertyName("station")]
    public Station Station { get; set; } = new();

    [JsonPropertyName("period")]
    public PeriodData Period { get; set; } = new();

    [JsonPropertyName("value")]
    public List<ValueEntry> Values { get; set; } = new();
}
