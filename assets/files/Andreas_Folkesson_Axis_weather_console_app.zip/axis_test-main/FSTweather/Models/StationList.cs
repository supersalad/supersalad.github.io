using System.Text.Json.Serialization;

namespace FSTweather.Models;

public class StationList
{
    [JsonPropertyName("key")]
    public string Key { get; set; } = string.Empty;

    [JsonPropertyName("updated")]
    public long Updated { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("summary")]
    public string Summary { get; set; } = string.Empty;

    [JsonPropertyName("station")]
    public List<Station> Stations { get; set; } = new();
}