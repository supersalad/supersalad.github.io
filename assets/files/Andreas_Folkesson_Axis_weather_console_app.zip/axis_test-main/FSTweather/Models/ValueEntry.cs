using System.Text.Json.Serialization;

namespace FSTweather.Models;

public class ValueEntry
{
    [JsonPropertyName("date")]
    public long Date { get; set; }

    [JsonPropertyName("value")]
    public string ValueString { get; set; } = string.Empty;

    [JsonPropertyName("quality")]
    public string Quality { get; set; } = string.Empty;

    [JsonIgnore]
    public double Value => string.IsNullOrEmpty(ValueString) ? 0 : double.Parse(ValueString, System.Globalization.CultureInfo.InvariantCulture);
}