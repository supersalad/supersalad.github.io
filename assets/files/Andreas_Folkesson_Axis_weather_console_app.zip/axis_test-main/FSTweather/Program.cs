﻿using System.CommandLine;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using FSTweather.Services;
using FSTweather.Services.Interfaces;
using FSTweather.Logic;
using FSTweather.Configuration;
using FSTweather.Formatting;

// Set up configuration
var configuration = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json", optional: false)
    .Build();

// Set up dependency injection
var services = new ServiceCollection();

// Register configuration
var smhiApiSettings = configuration.GetSection("SmhiApi").Get<SmhiApiSettings>()
    ?? throw new InvalidOperationException("SmhiApi configuration is missing");
services.AddSingleton(smhiApiSettings);

var rainfallSettings = configuration.GetSection("RainfallService").Get<RainfallServiceSettings>()
    ?? throw new InvalidOperationException("RainfallService configuration is missing");
services.AddSingleton(rainfallSettings);

// Register services
services.AddHttpClient<ISmhiApiClient, SmhiApiClient>();
services.AddSingleton<TemperatureService>();
services.AddSingleton<RainfallService>();

var serviceProvider = services.BuildServiceProvider();

// Create commands
var rootCommand = new RootCommand("SMHI Weather Data CLI Application");

var avgTempCommand = new Command("avg-temp", "Calculates average temperature across Sweden (last hour)");
var rainfallLundCommand = new Command("rainfall-lund", "Calculates total rainfall for Lund (latest months)");
var stationTempsCommand = new Command("station-temps", "Prints hourly temperature per station with cancellation");
var testApiCommand = new Command("test-api", "Test the SMHI API client by listing temperature stations");

// Set up command handlers using services
avgTempCommand.SetHandler(async () =>
{
    try
    {
        var temperatureService = serviceProvider.GetRequiredService<TemperatureService>();
        var result = await temperatureService.GetAverageTemperatureAsync(CancellationToken.None);
        if (result.HasValue)
        {
            Console.WriteLine($"The average temperature in Sweden for the last hour was {OutputFormatter.FormatTemperature(result.Value)}");
        }
    }
    catch (NotImplementedException)
    {
        Console.WriteLine("Average temperature calculation not yet implemented");
    }
});

rainfallLundCommand.SetHandler(async () =>
{
    try 
    {
        var rainfallService = serviceProvider.GetRequiredService<RainfallService>();
        var (rainfall, from, to) = await rainfallService.GetTotalRainfallInLundAsync();
        if (rainfall.HasValue)
        {
            Console.WriteLine($"Total rainfall in Lund {OutputFormatter.FormatDateRange(from, to)} was {OutputFormatter.FormatRainfall(rainfall.Value)}");
        }
    }
    catch (NotImplementedException)
    {
        Console.WriteLine("Rainfall in Lund calculation not yet implemented");
    }
});

stationTempsCommand.SetHandler(async () =>
{
    try
    {
        Console.WriteLine("Continuous station temperatures. Press any key to stop.");

        using var cts = new CancellationTokenSource();
        _ = Task.Run(() =>
        {
            Console.ReadKey(intercept: true);
            Console.WriteLine("Key pressed — cancelling...");
            cts.Cancel();
        });

        var temperatureService = serviceProvider.GetRequiredService<TemperatureService>();
        await temperatureService.PrintStationTemperaturesAsync(cts.Token);
    }
    catch (NotImplementedException)
    {
        Console.WriteLine("Station temperatures display not yet implemented");
    }
    catch (OperationCanceledException)
    {
        Console.WriteLine("\nOperation cancelled.");
    }
});

// Add test API command handler
testApiCommand.SetHandler(async () =>
{
    try
    {
        var apiClient = serviceProvider.GetRequiredService<ISmhiApiClient>();
        var stations = await apiClient.GetStationsAsync(1); // 1 is the parameter ID for temperature
        Console.WriteLine($"Found {stations.Stations.Count} temperature stations:");
        foreach (var station in stations.Stations.Take(5))
        {
            Console.WriteLine($"- {station.Name} (ID: {station.Id}): {station.Active}, Lat: {station.Latitude:F4}, Long: {station.Longitude:F4}");
        }
        if (stations.Stations.Count > 5)
        {
            Console.WriteLine("... (showing first 5 stations only)");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error testing API: {ex.Message}");
    }
});

rootCommand.AddCommand(avgTempCommand);
rootCommand.AddCommand(rainfallLundCommand);
rootCommand.AddCommand(stationTempsCommand);
rootCommand.AddCommand(testApiCommand);

return await rootCommand.InvokeAsync(args);
