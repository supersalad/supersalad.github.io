using FSTweather.Models;

namespace FSTweather.Services.Interfaces;

public interface ISmhiApiClient
{
    Task<StationList> GetStationsAsync(int parameterId);
    Task<StationData?> GetStationDataAsync(int parameterId, int stationId, string period);
}