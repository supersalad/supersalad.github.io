using FSTweather.Models;
using FSTweather.Services.Interfaces;
using FSTweather.Configuration;
using System.Text.Json;

namespace FSTweather.Services;

public class SmhiApiClient : ISmhiApiClient
{
    private readonly HttpClient _httpClient;

    public SmhiApiClient(HttpClient httpClient, SmhiApiSettings settings)
    {
        _httpClient = httpClient;
        _httpClient.BaseAddress = new Uri(settings.BaseUrl);
    }

    public async Task<StationList> GetStationsAsync(int parameterId)
    {
        try
        {
            var url = $"parameter/{parameterId}.json";
            var response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();
            
            var content = await response.Content.ReadAsStringAsync();
            var stations = JsonSerializer.Deserialize<StationList>(content);
            return stations ?? new StationList();
        }
        catch (HttpRequestException ex)
        {
            throw new Exception($"Failed to fetch stations: {ex.Message}", ex);
        }
        catch (JsonException ex)
        {
            throw new Exception($"Failed to parse station data: {ex.Message}", ex);
        }
    }

    public async Task<StationData?> GetStationDataAsync(int parameterId, int stationId, string period)
    {
        try
        {
            var url = $"parameter/{parameterId}/station/{stationId}/period/{period}/data.json";
            var response = await _httpClient.GetAsync(url);
            
            response.EnsureSuccessStatusCode();
            var content = await response.Content.ReadAsStringAsync();
            var stationData = JsonSerializer.Deserialize<StationData>(content);
            return stationData;
        }
        catch (HttpRequestException ex)
        {
            throw new Exception($"Failed to fetch station data: {ex.Message}", ex);
        }
        catch (JsonException ex)
        {
            throw new Exception($"Failed to parse station data: {ex.Message}", ex);
        }
    }
}