# FSTWeather - SMHI Weather Data CLI Application

A .NET 8 console application that interacts with the Swedish Meteorological and Hydrological Institute (SMHI) open weather API to provide real-time weather data and statistics.

## 🎯 Assignment Overview

This application solves three core weather data challenges:

1. **Average Temperature**: Calculate the average temperature across Sweden for the last hour
2. **Lund Rainfall**: Calculate total rainfall in Lund for the latest months
3. **Station Monitoring**: Display real-time temperature data from all weather stations with cancellation support

## 🏗️ Architecture & Design

### Project Structure
```
FSTWeather/
├── Program.cs                      # CLI entry point and dependency injection setup
├── appsettings.json               # Configuration for API endpoints and settings
├── Services/
│   ├── Interfaces/
│   │   └── ISmhiApiClient.cs      # API client interface for testability
│   └── SmhiApiClient.cs           # HTTP client for SMHI API communication
├── Logic/
│   ├── TemperatureService.cs      # Business logic for temperature operations
│   └── RainfallService.cs         # Business logic for rainfall calculations
├── Models/
│   ├── Station.cs                 # Weather station data model
│   ├── StationData.cs             # Temperature/rainfall measurement data
│   ├── StationList.cs             # API response wrapper for station lists
│   ├── ValueEntry.cs              # Individual measurement value
│   └── PeriodData.cs              # Time period information
├── Configuration/
│   ├── SmhiApiSettings.cs         # API configuration settings
│   └── RainfallServiceSettings.cs # Service-specific configuration
├── Formatting/
│   └── OutputFormatter.cs        # Consistent output formatting utilities
└── FSTWeather.Tests/             # Comprehensive test suite
    ├── TemperatureServiceTests.cs # Unit tests for temperature logic
    ├── RainfallServiceTests.cs   # Unit tests for rainfall logic
    ├── ErrorHandlingTests.cs     # Error scenarios and edge cases
    ├── IntegrationTests.cs       # End-to-end tests with real data
    └── testdata/                 # Sample SMHI API responses for testing
```

### Key Design Principles

✅ **No Magic Strings**: All constants, API endpoints, and parameter IDs are defined in configuration files or enums  
✅ **Clear Naming**: Self-documenting class and method names that express intent  
✅ **Separation of Concerns**: Clean separation between API communication, business logic, and presentation  
✅ **Dependency Injection**: Proper IoC container setup for testability and maintainability  
✅ **Interface-Driven Design**: Abstract API dependencies behind interfaces for easy testing and future extensibility  
✅ **Comprehensive Testing**: Unit tests, integration tests, and error handling scenarios  
✅ **Configuration-Based**: External configuration for API settings and service parameters  
✅ **Async/Await**: Proper asynchronous programming throughout the application  
✅ **Fixed api version**: For predictable future operation, SMHI api version set to 1.0  

## 🚀 Quick Start

### Prerequisites
- .NET 8 SDK or later
- Internet connection for SMHI API access

### Building the Application
```bash
# Navigate to the project directory
cd FSTweather

# Restore dependencies and build
dotnet build

# Or build and run in one step
dotnet run -- [command]
```

### Running Tests
```bash
# Run all tests
dotnet test FSTWeather.Tests

# Run tests with detailed output
dotnet test FSTWeather.Tests --verbosity normal

# Run specific test category
dotnet test FSTWeather.Tests --filter "TemperatureService"
```

## 📋 Available Commands

The application provides four main commands:

### 1. Average Temperature in Sweden
```bash
dotnet run -- avg-temp
```
Calculates and displays the average temperature across all active weather stations in Sweden for the last hour.

**Example output:**
```
The average temperature in Sweden for the last hour was 12.5°C
```

### 2. Total Rainfall in Lund
```bash
dotnet run -- rainfall-lund
```
Calculates the total rainfall in Lund for the latest available months period.

**Example output:**
```
Total rainfall in Lund May 30, 2025 - Oct 07, 2025 was 187.4 mm
```

### 3. Real-time Station Temperature Monitoring
```bash
dotnet run -- station-temps
```
Continuously displays temperature readings from all weather stations with a 100ms delay between stations. Press any key to cancel the operation.

**Example output:**
```
Continuous station temperatures. Press any key to stop.
Stockholm: 15.2°C
Göteborg: 13.8°C
Malmö: 16.1°C
...
Key pressed — cancelling...
Operation cancelled.
```

### 4. API Connection Test
```bash
dotnet run -- test-api
```
Tests the connection to SMHI API and displays a sample of available weather stations.

**Example output:**
```
Found 156 temperature stations:
- Stockholm (ID: 98210): True, Lat: 59.3508, Long: 18.1135
- Göteborg (ID: 71420): True, Lat: 57.6682, Long: 11.9865
...
```

## 🧪 Testing Strategy

The application includes a comprehensive test suite with **17 tests**:

### Test Categories

**Unit Tests** (`TemperatureServiceTests.cs`, `RainfallServiceTests.cs`)
- Business logic validation with mocked dependencies
- Edge cases like missing data, empty responses, and invalid values
- Proper calculation verification

**Error Handling Tests** (`ErrorHandlingTests.cs`)
- Network failure scenarios
- API timeout and error responses  
- Cancellation token handling

**Integration Tests** (`IntegrationTests.cs`)
- End-to-end testing with real SMHI API response formats
- JSON deserialization validation
- Service orchestration verification

### Test Data
The `testdata/` folder contains actual SMHI API responses for:
- Temperature station data
- Rainfall measurement data
- Station list responses

This ensures tests validate against real-world API data structures.

## 🔧 Configuration

### Application Settings (`appsettings.json`)
```json
{
  "SmhiApi": {
    "BaseUrl": "https://opendata-download-metobs.smhi.se/api/version/1.0/"
  },
  "RainfallService": {
    "LundStationId": 53430
  }
}
```

### Key Configuration Points
- **SMHI API Base URL**: Configurable endpoint for the weather data API
- **Lund Station ID**: Specific weather station identifier for rainfall measurements
- **HTTP Client**: Configured with proper timeouts and retry policies

## 🎯 Highlights

### What Works Well
- **Clean Architecture**: Well-separated layers with clear responsibilities
- **Robust Error Handling**: Graceful handling of network issues and invalid data
- **Comprehensive Testing**: High test coverage with real API data validation
- **User-Friendly CLI**: Clear command structure with helpful output formatting
- **Type Safety**: Strong typing throughout with proper null handling
- **Performance**: Efficient async/await usage for non-blocking operations

### Data Quality Handling
- **Empty Data Exclusion**: Weather stations with no data are excluded from averages rather than treated as zero
- **Quality Validation**: Only processes measurements with valid quality indicators
- **Null Safety**: Robust handling of missing or malformed API responses

## 🚧 Future Enhancements

Given more development time, the following improvements would be valuable:

### Performance & Efficiency
- **Response Caching**: Implement intelligent caching to reduce API calls and bandwidth usage
- **Parallel Processing**: Concurrent station data fetching with proper throttling
- **Request Batching**: Optimize API calls by combining related requests

### Robustness & Reliability  
- **Retry Policies**: Exponential backoff for transient network failures
- **Structured Logging**: Comprehensive logging with correlation IDs for debugging

## 📊 API Integration

This application integrates with the [SMHI Open Data API](https://opendata.smhi.se/apidocs/metobs/index.html) using:

- **Parameter 1**: Air temperature measurements
- **Parameter 5**: Precipitation (rainfall) measurements  
- **Periods**: `latest-hour` for temperature, `latest-months` for rainfall

The integration is designed to be resilient to API changes and provides clear error messages when issues occur.

---